library(openxlsx)
initialize <- function(data, pValue, header, mode) {
  if (mode != "header") {
    tmp <- apply(data, 1, function(x) {
      bar <- rep(FALSE, length(x))
      for (i in seq_len(length(pValue))) {
        bar <- bar | x == pValue[i]
      }
      x[bar]
    }
    )
    bar <- rep(FALSE, length(tmp))
    for (i in seq_len(length(pValue))) {
      bar <- bar | tmp == pValue[i]
    }
    
    tmp2 <- data[as.numeric(rownames(data[bar, ])), ]
    
    tmp_footer <- apply(data, 1, function(x) {
      all(x == "")
    }
    )
    green_header <- as.numeric(rownames(data[bar, ]))
    footer <- as.numeric(rownames(data[tmp_footer, ]))
  }
  else{
    tmp <- apply(data, 1, function(x) {
      x[header == x]
    }
    )
    tmp2 <- NULL
    tmp_footer <- apply(data, 1, function(x) {
      all(x == "")
    }
    )
    green_header <- as.numeric(rownames(data[tmp == header, ]))
    footer <- as.numeric(rownames(data[tmp_footer, ]))
  }
  
  return(list(tmp = tmp, tmp2 = tmp2, gr_header = green_header, footer = footer))
}

getPotision_sigVar_Intercpt_rLim <- function(green_header, data, pValue, tmp2, col_count, col_intercept, table_rightLim) {
  for (j in seq_len(length(green_header))) {
    for (k in seq_len(ncol(data))) {
      for (l in seq_len(length(pValue))) {
        if (tmp2[j, k] == pValue[l]) {
          col_count[j] <- k
        }
      }
    }
  }
  for (j in seq_len(length(green_header))) {
    for (k in seq_len(length(data[green_header[j], ]))) {
      if (data[green_header[j], k] == "" & data[green_header[j] + 1, k] != "") {
        col_intercept[j] <- k
      }
    }
  }
  for (j in seq_len(length(green_header))) {
    for (k in setdiff(seq_len(length(data[green_header[j], ])), seq_len((col_intercept[j])))) {
      if (data[green_header[j], k] == "") {
        table_rightLim[j] <- (k - 1)
        break
      }
      else if (k == ncol(data)) {
        table_rightLim[j] <- k
      }
    }
  }
  return(list(count = col_count, intercept = col_intercept, rightLim = table_rightLim))
}


removeNA <- function(factor_row, adj) {
  if (adj == TRUE) {
    for (i in seq_len(length(factor_row))) {
      if (!(is.integer(factor_row[[i]]) & length(factor_row[[i]]) == 0L)) {
        options(warn = -1)
        if (all(is.na(factor_row[[i]]))) {
          factor_row[[i]] <- integer(0)
        }
        options(warn = 0)
      }
      if (any(is.na(factor_row[[i]]))) {
        factor_row[[i]] <- as.vector(stats::na.omit(factor_row[[i]]))
      }
    }
  }
  else {
    for (i in seq_len(length(factor_row))) {
      if (!(is.integer(factor_row[i]) & length(factor_row[i]) == 0L)) {
        options(warn = -1)
        if (is.na(factor_row[i])) {
          factor_row[i] <- integer(0)
        }
        options(warn = 0)
      }
    }
  }
  return(factor_row)
}


#'
#' Coloring the signigicant variables and corresponding p values in statistical tests tables on a EXCEL sheet.
#' @encoding UTF-8
#'
#' @param dataName The name of a csv-file you want to edit with coloring.
#' @param fileName The name of a Excel-file you want to save as.
#' @param level The significance level applied in coloring significant variables and p values.
#' @param pValue The character object which indicates the column name in each stitistical test tables.
#' @param significanceColor The fore-ground-color of the significant variables.
#' @param headerColor The fore-ground-color of the headers of a data-frame.
#' @param fontSize Font-size.
#' @param fontName Font-name.
#' @param fontColor The color of fonts.
#' @param intercept Allows you to color significant intercept variable with the fontColor.
#' @param adj Allows you yo adjust shifted statistical test tables.
#' @param fileEncoding File-encoding.
#'
#' @importFrom stats na.omit
#' @importFrom utils read.table
#' @importFrom openxlsx createWorkbook
#' @importFrom openxlsx addWorksheet
#' @importFrom openxlsx createStyle
#' @importFrom openxlsx addStyle
#' @importFrom openxlsx writeData
#' @importFrom openxlsx modifyBaseFont
#' @importFrom openxlsx saveWorkbook
#'
#' @export
#'
excelColor <- function(dataName, fileName, level = 0.05, pValue = c("Pr(>|z|)", "Pr(>|t|)", "p-value"), significanceColor = "#FFFF00", headerColor = "#92D050", fontSize = 11, fontName = "Yu Gothic", fontColor = "#000000",  intercept = FALSE, adj = TRUE, fileEncoding = "CP932") {
  options(warn = -1)
  if (is.na(dataName)) {
    stop("There is no data-name")
  }
  options(warn = 0)
  if (is.na(fileName)) {
    stop("There is no file-name")
  }
  if (!(is.character(fileName))) {
    stop("The file-name must be character")
  }
  data <- utils::read.table(paste0(dataName, ".csv"), fill = TRUE, header = FALSE, sep = ",", blank.lines.skip = FALSE, fileEncoding = fileEncoding)
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Sheet 1")
  st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize)
  openxlsx::addStyle(wb, "Sheet 1", style = st, cols = 1:2, rows = 1:2)
  openxlsx::writeData(wb, sheet = "Sheet 1", x = data, colNames = F, withFilter = F)
  openxlsx::modifyBaseFont(wb, fontSize = fontSize, fontColour = fontColor, fontName = fontName)
  
  init <- initialize(data, pValue, mode = "test")
  tmp <- init$tmp
  tmp2 <- init$tmp2
  green_header <- init$gr_header
  footer <- init$footer
  col_count <- NULL
  col_intercept <- NULL
  table_rightLim <- NULL
  if (adj == TRUE) {
    cols <- getPotision_sigVar_Intercpt_rLim(green_header, data,
                                             pValue, tmp2,  col_count,
                                             col_intercept, table_rightLim)
    col_count <- cols$count
    col_intercept <- cols$intercept
    table_rightLim <- cols$rightLim
    
    #setStyle for headers
    for (i in seq_len(length(green_header))) {
      st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = headerColor)
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_intercept[i]:table_rightLim[i], rows = green_header[i])
    }
    #count <- 1
    factor_list <- list(NULL)
    factor_list <- mkFactorList(green_header, footer, factor_list, 1, data)
    
    factor_row <- list(NULL)
    for (i in seq_len(length(factor_list))) {
      bar <-  factor_list[[i]]
      factor_row[[i]] <- bar[as.numeric(data[factor_list[[i]], col_count[i]]) < level]
    }
    
    #removing NA
    factor_row <- removeNA(factor_row, adj)
    
    #write data
    writeDatas(factor_list, data, wb, tmp)
    
    #setStyle for significant variables
    st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = significanceColor)
    for (i in seq_len(length(factor_list))) {
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_count[i], rows = factor_row[[i]])
    }
    
    if (intercept == TRUE) {
      for (i in seq_len(length(factor_list))) {
        openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_intercept[i], rows = factor_row[[i]])
      }
    }else {
      for (i in seq_len(length(factor_list))) {
        openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_intercept[i], rows = setdiff(factor_row[[i]], green_header[i] + 1))
      }
    }
  }else {
    st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = headerColor)
    for (k in seq_len(ncol(data))) {
      for (l in seq_len(length(pValue))) {
        if (tmp2[1, k] ==  pValue[l]) {
          col_count[1] <- k
        }
      }
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = k, rows = green_header)
    }
    
    options(warn = -1)
    factor_row <- as.numeric(rownames(data[replace(as.numeric(data[, col_count[1]]) < level, is.na(as.numeric(data[, col_count[1]]) < level), FALSE), ]))
    options(warn = 0)
    
    #removing NA
    factor_row <- removeNA(factor_row, adj)
    
    #count <- 1
    factor_list <- list(NULL)
    factor_list <- mkFactorList(green_header, footer, factor_list, 1, data)
    
    #write data
    writeDatas(factor_list, data, wb)
    
    st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = significanceColor)
    openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_count[1], rows = factor_row)
    
    if (intercept == TRUE) {
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = 1, rows = factor_row)
    }else {
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = 1, rows = setdiff(factor_row, green_header[i] + 1))
    }
  }
  
  openxlsx::saveWorkbook(wb, paste0(fileName, ".xlsx"), overwrite = TRUE)
}

getPosition_intercpt_rightLim <- function(green_header, data, col_intercept, table_rightLim) {
  for (j in seq_len(length(green_header))) {
    for (k in seq_len(length(data[green_header[j], ]))) {
      if (data[green_header[j], k] == "" & data[green_header[j] + 1, k] != "") {
        col_intercept[j] <- k
      }else {
        if (k < ncol(data)) {
          if (data[green_header[j], k] == "" & data[green_header[j] + 1, k] == "" & data[green_header[j], k + 1] != "") {
            col_intercept[j] <- k + 1
          }
        }
      }
    }
    if (is.na(col_intercept[j])) {
      col_intercept[j] <- 1
    }
  }
  for (j in seq_len(length(green_header))) {
    for (k in setdiff(seq_len(length(data[green_header[j], ])), seq_len((col_intercept[j])))) {
      if (data[green_header[j], k] == "") {
        table_rightLim[j] <- (k - 1)
        break
      }
      else if (k == ncol(data)) {
        table_rightLim[j] <- k
      }
    }
  }
  return(list(intercept = col_intercept, rightLim = table_rightLim))
}

mkFactorList <- function(green_header, footer, factor_list, count, data) {
  for (i in seq_len(length(green_header))) {
    if (!is.na(footer[count])) {
      while (green_header[i] >= (footer[count] - 1) & count != length(footer)) {
        count <- count + 1
      }
      if (count != length(footer)) {
        factor_list[[i]] <- (green_header[i] + 1):(footer[count] - 1)
        count <- count + 1
      }else {
        if (green_header[i] < footer[count]) {
          factor_list[[i]] <- (green_header[i] + 1):(footer[count] - 1)
        }else {
          factor_list[[i]] <- (green_header[i] + 1):nrow(data)
        }
      }
    }else {
      factor_list[[i]] <- (green_header[i] + 1):nrow(data)
    }
  }
  return(factor_list)
}

writeDatas <- function(factor_list, data, wb, tmp = NULL) {
  options(warn = -1)
  for (i in seq_len(length(factor_list))) {
    bar <- data[factor_list[[i]], ]
    for (j in seq_len(ncol(data[factor_list[[i]], ]))) {
      bar[bar[, j] == "", j] <- NA
      if (!is.null(tmp)) {
        tmp <- data[factor_list[[i]], col_intercept[i] - 1 + j]
        tmp[tmp == ""] <- NA
      }
      if (!any((is.na(as.numeric(stats::na.omit(bar[, j])))))) {
        if (all(as.numeric(stats::na.omit(bar[, j])) == as.character(as.numeric(stats::na.omit(bar[, j]))))) {
          bar[, j] <- as.numeric(bar[, j])
        }
      }
    }
    openxlsx::writeData(wb, sheet = "Sheet 1", x = bar, startRow = factor_list[[i]][1], startCol = 1, colNames = F, withFilter = F)
  }
  options(warn = 0)
  
  
}
#'
#' Coloring headers of tables on a EXCEL sheet
#' @encoding UTF-8
#'
#' @param dataName The name of a csv-file you want to edit with coloring.
#' @param fileName The name of a Excel-file you want to save as.
#' @param header The character object included in each headers of tables.
#' @param headerColor The fore-ground-color of the headers of a data-frame.
#' @param fontSize Font-size.
#' @param fontName Font-name.
#' @param fontColor The color of fonts.
#' @param adj Allows you yo adjust shifted statistical test tables.
#' @param fileEncoding File-encoding.
#'
#' @importFrom stats na.omit
#' @importFrom utils read.table
#' @importFrom openxlsx createWorkbook
#' @importFrom openxlsx addWorksheet
#' @importFrom openxlsx createStyle
#' @importFrom openxlsx addStyle
#' @importFrom openxlsx writeData
#' @importFrom openxlsx modifyBaseFont
#' @importFrom openxlsx saveWorkbook
#'
#' @export
#'
excelHeadColor <- function(dataName, fileName, header, headerColor = "#92D050", fontSize = 11, fontName = "Yu Gothic", fontColor = "#000000", adj = TRUE, fileEncoding = "CP932") {
  options(warn = -1)
  if (is.na(dataName)) {
    stop("There is no data-name")
  }
  options(warn = 0)
  if (is.na(fileName)) {
    stop("There is no file-name")
  }
  if (!(is.character(fileName))) {
    stop("The file-name must be character")
  }
  data <- utils::read.table(paste0(dataName, ".csv"), fill = TRUE, header = FALSE, sep = ",", blank.lines.skip = FALSE, fileEncoding = fileEncoding)
  wb <- openxlsx::createWorkbook()
  openxlsx::addWorksheet(wb, "Sheet 1")
  st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize)
  openxlsx::addStyle(wb, "Sheet 1", style = st, cols = 1:2, rows = 1:2)
  openxlsx::writeData(wb, sheet = "Sheet 1", x = data, colNames = F, withFilter = F)
  openxlsx::modifyBaseFont(wb, fontSize = fontSize, fontColour = fontColor, fontName = fontName)
  
  init <- initialize(data, header = header, mode = "header")
  tmp <- init$tmp
  green_header <- init$gr_header
  footer <- init$footer
  col_intercept <- NA
  table_rightLim <- NULL
  
  if (adj == TRUE) {
    cols <- getPosition_intercpt_rightLim(green_header, data, col_intercept, table_rightLim)
    col_intercept <- cols$intercept
    table_rightLim <- cols$rightLim
    
    #setStyle for headers
    for (i in seq_len(length(green_header))) {
      st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = headerColor)
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = col_intercept[i]:table_rightLim[i], rows = green_header[i])
    }
    
    factor_list <- list(NULL)
    factor_list <- mkFactorList(green_header, footer, factor_list, 1, data)
    
    #write data
    writeDatas(factor_list, data, wb)
  }
  else {
    st <- openxlsx::createStyle(fontName = fontName, fontSize = fontSize, fgFill = headerColor)
    for (k in seq_len(ncol(data))) {
      openxlsx::addStyle(wb, "Sheet 1", style = st, cols = k, rows = green_header)
    }
    factor_list <- list(NULL)
    factor_list <- mkFactorList(green_header, footer, factor_list, 1, data)
    
    #write data
    writeDatas(factor_list, data, wb)
  }
  openxlsx::saveWorkbook(wb, paste0(fileName, ".xlsx"), overwrite = TRUE)
}