reg_fun <- function(data, fileName, dependentVariable = NULL, level = 0.05 ,ci = TRUE ,sigma = FALSE, df = FALSE, R2 = TRUE, R =TRUE , R2.adj =TRUE, R.adj = FALSE, N=TRUE, dcml.plc = 5, AIC = TRUE, BIC = FALSE, append = TRUE){ 　
  if(is.null(dependentVariable)){dependentVariable <- colnames(data)[1]}
  y <- data[,dependentVariable] 
  ans <- lm(y ~., data = data[, setdiff(colnames(data), dependentVariable)]) 
  s.ans <- summary(ans) 
  round(s.ans$coefficient,5)
  coe <- round(s.ans$coefficient,dcml.plc)
  ci <-  round(cbind(s.ans$coefficients[,1]-qt(level/2, s.ans$df[2])*s.ans$coefficients[,2],s.ans$coefficients[,2]+qt(level/2, s.ans$df[2])*s.ans$coefficients[,2]),dcml.plc)
  colnames(ci) <- c(paste0(100-100*level, "%CI.low"), paste0(100-100*level, "%CI.up"))
  res <- cbind(coe, ci)
  
  if(df == TRUE){df <- data.frame(matrix(rep(round(s.ans$df, dcml.plc),nrow(coe)),nrow = 1 ))}
  if(R2 == TRUE){R2 <- round(s.ans$r.squared, dcml.plc)}
  if(R == TRUE){R <- round(sqrt(s.ans$r.squared), dcml.plc)}
  if(R2.adj == TRUE){R2.adj <- round(s.ans$adj.r.squared, dcml.plc)}
  if(R.adj == TRUE){R.adj <- round(sqrt(s.ans$adj.r.squared), dcml.plc)}
  if(AIC == TRUE){AIC <- round(AIC(ans), dcml.plc)}
  if(BIC == TRUE){BIC <- round(BIC(ans), dcml.plc)}
  if(N == TRUE){N <- nrow(data)}
  
  colName <- c("sigma","df","R", "R2", "R.adj", "R2.adj", "AIC", "BIC", "N")
  col_list <-list(sigma,df,R, R2, R.adj, R2.adj, AIC, BIC, N)
  for(i in  1:length(col_list)){
    options(warn=-1)
    if(any(col_list[[i]]) != FALSE){
      res <- cbind(res, col_list[[i]])
      colnames(res)[ncol(res)] <- colName[i] 
    }
    options(warn=0)
  }
  #colnames(res) <- c(colnames(coe), colnames(ci), c("sigma","df","R", "R2", "R.adj", "R2.adj", "AIC", "BIC", "N"))
  fact <- colnames(data)[sapply(data,is.factor) | sapply(data,is.character)]
  
  for(f in fact){
    idx <- grep(paste0("^",f),rownames(coe))
    if(is.na(idx[1])){
      idx <-  grep(paste0("^`",f,"`"),rownames(coe))
    }
    rownames(coe)[idx] <- paste0(rownames(coe)[idx],"(vs ",levels(as.factor(data[,f]))[1],")")
  }
  
  if(nrow(res) >= 2){
    res[2:nrow(res),setdiff(colnames(res), c(colnames(coe),colnames(ci)))] <- ""
  }
  rowName <- data.frame(matrix(colnames(res),nrow=1))
  colnames(rowName) <- colnames(res)
  res <- cbind(c("",rownames(res)) , rbind(rowName, res))
  table <- rbind(c(dependentVariable, rep("", ncol(res)-1)), res, rep("", ncol(res)))
  options(warn=-1)
  write.table(table,paste0(fileName, ".csv"),append=append,sep = ",", row.names=F,col.names=F,fileEncoding="CP932")
  options(warn=0)
}