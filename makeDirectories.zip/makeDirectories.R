mkDirFor_result_data <- function(parentDirName, childDirName, extension, file) {
  if (is.na(strsplit(file, "\\.")[[1]][2]) & any(is.na(extension))) {
    dir.create(paste0(getwd(), "/", parentDirName, "/", childDirName, "/", "No Extension"))
    extension[is.na(extension)] <- ""
  }
  if (!is.na(any(extension == strsplit(file, "\\.")[[1]][length(strsplit(file, "\\.")[[1]])]))) {
    if (any(extension == strsplit(file, "\\.")[[1]][length(strsplit(file, "\\.")[[1]])])) {
      options(warn = -1)
      dir.create(paste0(getwd(), "/", parentDirName, "/", childDirName, "/", strsplit(file, "\\.")[[1]][length(strsplit(file, "\\.")[[1]])]))
      options(warn = 0)
      extension[extension == strsplit(file, "\\.")[[1]][length(strsplit(file, "\\.")[[1]])]] <- ""
    }
  }
  if (is.na(strsplit(file, "\\.")[[1]][2])) {
    file.copy(paste0(getwd(), "/", file), paste0(getwd(), "/", parentDirName, "/", childDirName, "/", "No Extension", "/", file))
  }else {
    file.copy(paste0(getwd(), "/", file), paste0(getwd(), "/", parentDirName, "/", childDirName, "/", strsplit(file, "\\.")[[1]][length(strsplit(file, "\\.")[[1]])], "/", file))
  }
  return(extension)
}

mkDir_noArrange_esult_data <- function(parentDirName, childDirName, file) {
  file.copy(paste0(getwd(), "/", file), paste0(getwd(), "/", parentDirName, "/", childDirName, "/", file))
}
#'
#' Making directories to organize three kinds of datas: data-sets,  script-files and result-files
#' @encoding UTF-8
#'
#' @param parentDirName The name of a parent-directory containing organize datas-files, script-files and result-files.
#' @param dataDirName The name of a directory to organize data-files.
#' @param programmingDirName The name of a directory to organize script-files.
#' @param resultDirName The name of a directory to organize result-files.
#' @param updateTime The time used to divide data-filese into two directories, one is for datas and the other is for results.
#' @param arrange Allows you to organize data-files in the form of file extensions.
#'
#' @export
#'
mkDirectories <- function(parentDirName, dataDirName="data", programmingDirName="program", resultDirName="result", updateTime=1, arrange = TRUE) {
  dir.create(paste0(getwd(), "/", parentDirName))
  dir.create(paste0(getwd(), "/", parentDirName, "/", dataDirName))
  dir.create(paste0(getwd(), "/", parentDirName, "/", programmingDirName))
  dir.create(paste0(getwd(), "/", parentDirName, "/", resultDirName))
  files <- list.files()
  R.files <- grep("\\.R$", files)
  
  fileExtension <- NULL
  for (i in seq_len(length(strsplit(files[- (R.files)], "\\.")))) {
    if (length(strsplit(files[- (R.files)], "\\.")[[i]]) == 1) {
      fileExtension[length(fileExtension) + 1] <- strsplit(files[- (R.files)], "\\.")[[i]][2]
    }else {
      fileExtension[length(fileExtension) + 1] <- strsplit(files[- (R.files)], "\\.")[[i]][length(strsplit(files[- (R.files)], "\\.")[[i]])]
    }
  }
  
  fileExtension <- unique(fileExtension)
  resultExtension <- fileExtension
  dataExtension <- fileExtension
  
  for (i in files[- (R.files)]) {
    if (!is.na(file.info(paste0(getwd(), "/", i))$mtime) &  i != parentDirName) {
      get_resultOrData <- as.numeric(as.POSIXct(as.list(file.info(paste0(getwd(), "/", i)))$mtime, format = "%Y-%m-%d  %H:%M:%S", tz = "Japan") - Sys.time(), units = "mins") > (-1) * updateTime * 60
      if (arrange == TRUE) {
        if (get_resultOrData) {
          resultExtension <- mkDirFor_result_data(parentDirName, resultDirName, resultExtension, i)
        }
        else {
          dataExtension <- mkDirFor_result_data(parentDirName, dataDirName, dataExtension, i)
        }
      }
      else {
        if (get_resultOrData) {
          mkDir_noArrange_esult_data(parentDirName, resultDirName, i)
        }
        else {
          mkDir_noArrange_esult_data(parentDirName, dataDirName, i)
        }
      }
    }
  }
  for (i in files[R.files]) {
    file.copy(paste0(getwd(), "/", i), paste0(getwd(), "/", parentDirName, "/", programmingDirName, "/", i))
  }
}