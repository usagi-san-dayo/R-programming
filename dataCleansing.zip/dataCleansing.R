library(openxlsx)
library(data.table)

mkNumericTable <- function(data, index) {
  table <- c(index, rep("", 7))
  table <- rbind(table, c("", "Missing values", "", "Replace the column B with the spesific numbers", "", "Breaks", "", "Labels"))
  options(warn = -1)
  if (length(unique(data[is.na(as.numeric(data[, index])), index])) > 0) {
    numericData <- cbind(rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         unique(data[is.na(as.numeric(data[, index])), index]),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))),
                         rep("", length(unique(data[is.na(as.numeric(data[, index])), index]))))
  }
  else{
    numericData <- NULL
  }
  options(warn = 0)
  table <- rbind(table, numericData)
  table <- rbind(table, rep("", 8))
  return(table)
}

mkFactorTable <- function(data, index) {
  table <- c(index, rep("", 8))
  table <- rbind(table, c("", "", "Levels", "", "Replace the column B with", "", "Pool the column B", "", "The Order of levels"))
  factorData <- cbind(rep("", nlevels(as.factor(data[, index]))),
                      paste0("No.", 1:nlevels(as.factor(data[, index]))), levels(as.factor(data[, index])),
                      rep("", nlevels(as.factor(data[, index]))),
                      rep("", nlevels(as.factor(data[, index]))),
                      rep("", nlevels(as.factor(data[, index]))),
                      rep("", nlevels(as.factor(data[, index]))),
                      rep("", nlevels(as.factor(data[, index]))),
                      rep("", nlevels(as.factor(data[, index]))))
  
  table <- rbind(table, factorData)
  table <- rbind(table, t(c(rep("", 9))))
  return(table)
}

dataClassifier <- function(data, index, dateIndex, dateList) {
  if (length(dateList[[dateIndex]]) > 1) {
    form1 <- paste0("%m", dateList[[dateIndex]][2], "%d", dateList[[dateIndex]][3], "%Y", dateList[[dateIndex]][1])
    form2 <- paste0("%Y", dateList[[dateIndex]][1], "%m", dateList[[dateIndex]][2], "%d", dateList[[dateIndex]][3])
    
    charData1 <- gsub(dateList[[dateIndex]][2], dateList[[dateIndex]][1], data[, index])
    charData1 <- gsub(dateList[[dateIndex]][3], dateList[[dateIndex]][1], charData1)
    options(warn = -1)
    dateData <- replace(charData1, charData1 == "", NA)
    charData1 <- as.vector(apply(as.data.frame(strsplit(dateData, dateList[[dateIndex]][1])), 2, function(x) {
      paste0(formatC(as.numeric(x[3]), width = 4, flag = "0"), "-",
             formatC(as.numeric(x[1]), width = 2, flag = "0"), "-",
             formatC(as.numeric(x[2]), width = 2, flag = "0"))
    }
    )
    )
    options(warn = 0)
    charData2 <- gsub(dateList[[dateIndex]][2], dateList[[dateIndex]][1], data[, index])
    charData2 <- gsub(dateList[[dateIndex]][3], dateList[[dateIndex]][1], charData2)
    options(warn = -1)
    dateData <- replace(charData2, charData2 == "", NA)
    charData2 <- as.vector(apply(as.data.frame(strsplit(dateData, dateList[[dateIndex]][1])), 2, function(x) {
      paste0(formatC(as.numeric(x[1]), width = 4, flag = "0"), "-",
             formatC(as.numeric(x[2]), width = 2, flag = "0"), "-",
             formatC(as.numeric(x[3]), width = 2, flag = "0"))
    }
    )
    )
    options(warn = 0)
  }
  else {
    delimiter <-  gsub("\\", "", dateList[[dateIndex]][1], fixed = TRUE)
    form1 <- paste0("%m", delimiter, "%d", delimiter, "%Y")
    form2 <- paste0("%Y", delimiter, "%m", delimiter, "%d")
    options(warn = -1)
    dateData <- replace(data[, index], data[, index] == "", NA)
    charData1 <- as.vector(apply(as.data.frame(strsplit(as.character(dateData), dateList[[dateIndex]][1])), 2, function(x) {
      paste0(formatC(as.numeric(x[3]), width = 4, flag = "0"), "-",
             formatC(as.numeric(x[1]), width = 2, flag = "0"), "-",
             formatC(as.numeric(x[2]), width = 2, flag = "0"))
    }
    )
    )
    charData2 <- as.vector(apply(as.data.frame(strsplit(as.character(dateData), dateList[[dateIndex]][1])), 2, function(x) {
      paste0(formatC(as.numeric(x[1]), width = 4, flag = "0"), "-",
             formatC(as.numeric(x[2]), width = 2, flag = "0"), "-",
             formatC(as.numeric(x[3]), width = 2, flag = "0"))
    }
    )
    )
    options(warn = 0)
  }
  return(list(list(form = form1, date = charData1), list(form = form2, date = charData2)))
}

changeColName <- function(data, colname, refData, rowNumber) {
  changedName <- NULL
  if (!is.na(refData[rowNumber, 2])) {
    changedName <- refData[rowNumber, 2]
  }
  else {
    changedName <- colname
  }
  return(changedName)
}


replaceMissVal <- function(data, refData, rowNumber) {
  lengthMissVal <- length(unique(data[is.na(as.numeric(data))]))
  tmp <- data
  for (j in 1:lengthMissVal) {
    if (!is.na(refData[rowNumber + 1 + j, 4])) {
      data <- replace(data, data == unique(tmp[is.na(as.numeric(tmp))])[j], refData[rowNumber + 1 + j, 4])
    }
  }
  return(data)
}

cutting <- function(data, refData, rowNumber) {
  if (!is.na(refData[rowNumber + 2,  8])) {
    labels <- strsplit(refData[rowNumber + 2, 8], ",")
    breaks <- strsplit(refData[rowNumber + 2, 6], ",")
    data <- cut(data, breaks = as.numeric(breaks[[1]]), labels = labels[[1]], right = FALSE)
  }
  else {
    breaks <- strsplit(refData[rowNumber + 2, 6], ",")
    data <- cut(data, breaks = as.numeric(breaks[[1]]), right = FALSE)
  }
  return(data)
}

orderer <- function(data, refData, rowNumber) {
  orderVector <- rep(NA, nlevels(as.factor(data)))
  factorLength <- 0
  rowIndex <- 1
  
  while (!is.na(refData[rowNumber + 1 + rowIndex, 2])) {
    factorLength <- factorLength + 1
    rowIndex <- rowIndex + 1
  }
  
  pooledFactor <- strsplit(refData[(rowNumber + 2):(rowNumber + 1 + factorLength), 7], "[+]")
  poolLevel <- list(NULL)
  for (i in seq_len(length(pooledFactor))) {
    if (length(pooledFactor[[i]]) > 1) {
      for (j in seq_len(length(pooledFactor[[i]]))) {
        if (!is.na(refData[rowNumber + 1 + as.numeric(pooledFactor[[i]][j]), 5])) {
          poolLevel[[i]]$pool <- paste0(poolLevel[[i]]$pool, "+",  refData[rowNumber + 1 + as.numeric(pooledFactor[[i]][j]), 5])
        }
        else {
          poolLevel[[i]]$pool <- paste0(poolLevel[[i]]$pool, "+",  refData[rowNumber + 1 + as.numeric(pooledFactor[[i]][j]), 3])
        }
        poolLevel[[i]]$levels <- append(poolLevel[[i]]$levels, as.numeric(pooledFactor[[i]][j]))
      }
      poolLevel[[i]]$pool <- substr(poolLevel[[i]]$pool, 2, nchar(poolLevel[[i]]$pool))
    }
  }
  
  for (i in seq_len(length(poolLevel))) {
    refData[rowNumber + 1 + poolLevel[[i]]$levels, 5] <- poolLevel[[i]]$pool
  }
  
  for (j in seq_len(factorLength)) {
    if (!is.na(refData[rowNumber + 1 + j, 9])) {
      orderNum <- as.numeric(refData[rowNumber + 1 + j, 9])
      if (!is.na(refData[rowNumber + 1 + j, 5])) {
        if (refData[rowNumber + 1 + j, 5] != "\"NA\"") {
          orderVector[orderNum] <- refData[rowNumber + 1 + j, 5]
        }
      }
      else {
        orderVector[orderNum] <- refData[rowNumber + 1 + j, 3]
      }
    }
  }
  remainLevels <- setdiff(levels(as.factor(data)), orderVector)
  count <- 1
  for (i in seq_len(length(orderVector))) {
    if (is.na(orderVector[i])) {
      orderVector[i] <- remainLevels[count]
      count <- count + 1
    }
  }
  return(factor(data, levels = orderVector))
}

pooledName <- function(data, refData, rowNumber) {
  pooledData <- pooler(data, refData, rowNumber)
  pooledFactor <- ""
  for (j in grep("[+]", levels(pooledData))) {
    pooledFactor <- paste0(pooledFactor, ".", levels(pooledData)[j])
  }
  return(substr(pooledFactor, 2, nchar(pooledFactor)))
}

pooler <- function(data, refData, rowNumber) {
  poolList <- strsplit(refData[(rowNumber + 2) : (rowNumber + 1 + nlevels(as.factor(data))), 7], "[+]")
  
  data <- as.character(data)
  for (j in seq_len(length(poolList))) {
    if (length(poolList[[j]]) > 1) {
      poolLevel <- ""
      for (k in seq_len(length(poolList[[j]]))) {
        if (!is.na(refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 5])) {
          poolLevel <- paste0(poolLevel, "+",  refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 5])
        }
        else {
          poolLevel <- paste0(poolLevel, "+",  refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 3])
        }
      }
      poolLevel <- substr(poolLevel, 2, nchar(poolLevel))
      for (k in seq_len(length(poolList[[j]]))) {
        if (!is.na(refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 5])) {
          data <- replace(data, data == refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 5], poolLevel)
        }
        else {
          data <- replace(data, data == refData[rowNumber + 1 + as.numeric(poolList[[j]][k]), 3], poolLevel)
        }
      }
    }
  }
  levels <- levels(as.factor(data))
  return(factor(data, levels = levels))
}

replacer <- function(data, refData, rowNumber) {
  refData[(rowNumber + 2) : (rowNumber + 1 + nlevels(as.factor(data))), 5] != ""
  levelsRow <- refData[(rowNumber + 2) : (rowNumber + 1 + nlevels(as.factor(data))), 5] != ""
  factorLength <- 0
  rowIndex <- 1
  
  while (!is.na(refData[rowNumber + 1 + rowIndex, 2])) {
    factorLength <- factorLength + 1
    rowIndex <- rowIndex + 1
  }
  
  data <- as.character(data)
  
  refData[(rowNumber + 2) : (rowNumber + 1 + factorLength), 3] <- replace(refData[(rowNumber + 2) : (rowNumber + 1 + factorLength), 3], is.na(refData[(rowNumber + 2) : (rowNumber + 1 + factorLength), 3]), "")
  for (j in 1:nlevels(as.factor(data))) {
    if (!is.na(levelsRow[j])) {
      if (refData[rowNumber + 1 + j, 5] == "\"NA\"") {
        data <- replace(data, data == refData[rowNumber + 1 + j, 3], NA)
      }
      else {
        data <- replace(data, data == refData[rowNumber + 1 + j, 3], refData[rowNumber + 1 + j, 5])
      }
    }
  }
  levels <- levels(as.factor(data))
  return(factor(data, levels = levels))
}

readData <- function(dataName, fileEncoding) {
  if (fileEncoding == "UTF-8" | fileEncoding == "Latin-1") {
    data <- data.table::fread(paste0(dataName, ".csv"), encoding = fileEncoding)
  }
  else {
    data <- data.table::fread(paste0(dataName, ".csv"), encoding = "unknown")
  }
  return(data)
}

mkTimeTable <- function(data, dateFormat, index, tableTime, leastNumOfDate) {
  asDatedVector <- rep(FALSE, nrow(data))
  dateList <- dateFormat
  for (j in seq_len(length(dateList))) {
    tmp <- NULL
    for (k in strsplit(as.character(data[, index]), dateList[[j]][1])) {
      tmp <- append(tmp, length(k))
    }
    if ((all(tmp[grep(dateList[[j]][1], data[, index])] == 3) & length(tmp[grep(dateList[[j]][1], data[, index])] == 3) > 0) | (length(dateList[[j]]) > 1 & all(tmp[grep(dateList[[j]][1], data[, index])] == 2) & length(tmp[grep(dateList[[j]][1], data[, index])] == 2))) {
      formCharData <- dataClassifier(data, index, j, dateList)
      options(warn = -1)
      rowData <- as.numeric(rownames(data[as.character(as.Date(data[, index], form = formCharData[[1]]$form, origin = "1970-01-01")) == formCharData[[1]]$date & !is.na(as.character(as.Date(data[, index], form = formCharData[[1]]$form, origin = "1970-01-01")) == formCharData[[1]]$date), ]))
      if (all(asDatedVector[rowData] == FALSE)) {
        asDatedVector[rowData] <- TRUE
      }
      
      rowData <- as.numeric(rownames(data[as.character(as.Date(data[, index], form = formCharData[[2]]$form, origin = "1970-01-01")) == formCharData[[2]]$date & !is.na(as.character(as.Date(data[, index], form = formCharData[[2]]$form, origin = "1970-01-01")) == formCharData[[2]]$date), ]))
      options(warn = 0)
      if (all(asDatedVector[rowData] == FALSE)) {
        asDatedVector[rowData] <- TRUE
      }
    }
  }
  tmp <- NULL
  for (j in seq_len(length(dateList))) {
    tmp <- append(tmp, grep(dateList[[j]][1], data[, index]))
  }
  tmp <- setdiff(seq_len(nrow(data)), tmp)
  if (length(asDatedVector[asDatedVector == TRUE]) > leastNumOfDate) {
    asDatedVector[tmp] <- TRUE
  }
  if (all(asDatedVector == TRUE)) {
    tableTime <- rbind(tableTime, c(index, ""))
    return(tableTime)
  }
  return(NULL)
}

writeTablesOnExcel <- function(tableNumeric, tableFactor, tableTime, dataName) {
  sheetNumeric <- list(table = tableNumeric, sheetName = "numeric")
  sheetFactor <- list(table = tableFactor, sheetName = "factor")
  sheetTime <- list(table = tableTime, sheetName = "Date")
  wb <- openxlsx::createWorkbook()
  for (i in list(sheetNumeric, sheetFactor, sheetTime)) {
    openxlsx::addWorksheet(wb, i$sheetName)
  }
  st <- openxlsx::createStyle(fontName = "Yu Gothic", fontSize = 11)
  for (i in list(sheetNumeric, sheetFactor, sheetTime)) {
    openxlsx::addStyle(wb, i$sheetName, style = st, cols = 1:2, rows = 1:2)
    openxlsx::writeData(wb, sheet = i$sheetName, x = i$table, colNames = F, withFilter = F)
  }
  openxlsx::modifyBaseFont(wb, fontSize = 11, fontColour = "#000000", fontName = "Yu Gothic")
  openxlsx::saveWorkbook(wb, paste0("dataCleansingForm_", dataName, "_.xlsx"), overwrite = TRUE)
}

mkTableNum_Fac <- function(data, index, numOrFac, tableNumeric, tableFactor) {
  options(warn = -1)
  charEqualNum <- (as.numeric(data[, index]) == data[, index])
  options(warn = 0)
  if (length(na.omit(data[charEqualNum == FALSE, index])) == 0 &  length(na.omit(data[charEqualNum == TRUE, index])) > 0 & nlevels(as.factor(data[, index])) > nrow(data) / numOrFac) {
    tableNumeric <- rbind(tableNumeric, mkNumericTable(data, index))
  }
  else {
    tableFactor <- rbind(tableFactor, mkFactorTable(data, index))
  }
  return(list(num = tableNumeric, fac = tableFactor))
}

cleansNumeric <- function(data, index, refData, append) {
  if (any(refData[, 1] == index)) {
    options(warn = -1)
    rowNumber <- as.numeric(rownames(refData[refData[, 1] == index & !is.na(refData[, 1]), ]))
    colnames(data)[colnames(data) == index] <- changeColName(data, index, refData, rowNumber)
    index <- changeColName(data, index, refData, rowNumber)
    if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 + length(unique(data[is.na(as.numeric(data[, index])), index]))), 4])) & length(unique(data[is.na(as.numeric(data[, index])), index])) > 0) {
      if (append == TRUE) {
        data <- cbind(data, replaceMissVal(data[, index], refData, rowNumber))
        colnames(data)[ncol(data)] <- paste0(index, "_missing Values replaced")
      }
      else {
        data[, index] <- replaceMissVal(data[, index], refData, rowNumber)
      }
    }
    data[, index] <- as.numeric(data[, index])
    options(warn = 0)
    if (any(!is.na(refData[rowNumber + 2, 6]))) {
      if (append == TRUE) {
        data <- cbind(data, cutting(data[, index], refData, rowNumber))
        colnames(data)[ncol(data)] <- paste0(index, "_categorized")
      }
      else {
        data[, index] <- cutting(data[, index], refData, rowNumber)
      }
    }
  }
  return(data)
}

cleansFactor <- function(data, index, refData, append) {
  if (any(refData[, 1] == index)) {
    pooling <- FALSE
    ordering <- FALSE
    options(warn = -1)
    rowNumber <- as.numeric(rownames(refData[refData[, 1] == index & !is.na(refData[, 1]), ]))
    options(warn = 0)
    colnames(data)[colnames(data) == index] <- changeColName(data, index, refData, rowNumber)
    index <- changeColName(data, index, refData, rowNumber)
    nrowLevel <- nlevels(as.factor(data[, index]))
    if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 +  nrowLevel), 5]))) { #5 for replace
      data[, index] <- replacer(data[, index], refData, rowNumber)
      if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 + nlevels(as.factor(data[, index]))), 7]))) { #7 for pool
        if (append == TRUE) {
          data <- cbind(data, pooler(data[, index], refData, rowNumber))
          colnames(data)[ncol(data)] <- paste0(index, "_", pooledName(data[, index], refData, rowNumber))
          index <- colnames(data)[ncol(data)]
        }
        else {
          data[, index] <- pooler(data[, index], refData, rowNumber)
        }
        pooling <- TRUE
        if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 +  nrowLevel), 9]))) { #9 for order
          data[, index] <- orderer(data[, index], refData, rowNumber)
          ordering <- TRUE
        }
      }
    }
    if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 + nlevels(as.factor(data[, index]))), 7])) & pooling == FALSE) {
      if (append == TRUE) {
        data <- cbind(data, pooler(data[, index], refData, rowNumber))
        colnames(data)[ncol(data)] <- paste0(index, "_", pooledName(data[, index], refData, rowNumber))
      }
      else {
        data[, index] <- pooler(data[, index], refData, rowNumber)
      }
      pooling <- TRUE
      if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 + nlevels(as.factor(data[, index]))), 9])) & ordering == FALSE) {
        data[, index] <- orderer(data[, index], refData, rowNumber)
        ordering <- TRUE
      }
    }
    if (any(!is.na(refData[(rowNumber + 2):(rowNumber + 1 + nlevels(as.factor(data[, index]))), 9])) & ordering == FALSE) {
      data[, index] <- orderer(data[, index], refData, rowNumber)
      ordering <- TRUE
    }
    data[, index] <- as.factor(data[, index])
  }
  return(data)
}

cleansDate <- function(data, index, refData, dateFormat) {
  if (any(refData[, 1] == index)) {
    asDatedVector <- rep(FALSE, nrow(data))
    dateList <- dateFormat
    options(warn = -1)
    rowNumber <- as.numeric(rownames(refData[refData[, 1] == index & !is.na(refData[, 1]), ]))
    colnames(data)[colnames(data) == index] <- changeColName(data, index, refData, rowNumber)
    index <- changeColName(data, index, refData, rowNumber)
    for (j in seq_len(length(dateList))) {
      tmp <- NULL
      for (k in strsplit(as.character(data[, index]), dateList[[j]][1])) {
        tmp <- append(tmp, length(k))
      }
      if (all(tmp[grep(dateList[[j]][1], data[, index])] == 3) | (length(dateList[[j]]) > 1 & all(tmp[grep(dateList[[j]][1], data[, index])] == 2))) {
        formCharData <- dataClassifier(data, index, j, dateList)
        rowData <- as.numeric(rownames(data[as.character(as.Date(data[, index], form = formCharData[[1]]$form, origin = "1970-01-01")) == formCharData[[1]]$date & !is.na(as.character(as.Date(data[, index], form = formCharData[[1]]$form, origin = "1970-01-01")) == formCharData[[1]]$date), ]))
        if (length(rowData) > 0) {
          if (all(asDatedVector[rowData] == FALSE)) {
            data[rowData, index] <- formCharData[[1]]$date[rowData]
            asDatedVector[rowData] <- TRUE
          }
        }
        rowData <- as.numeric(rownames(data[as.character(as.Date(data[, index], form = formCharData[[2]]$form, origin = "1970-01-01")) == formCharData[[2]]$date & !is.na(as.character(as.Date(data[, index], form = formCharData[[2]]$form, origin = "1970-01-01")) == formCharData[[2]]$date), ]))
        if (length(rowData) > 0) {
          if (all(asDatedVector[rowData] == FALSE)) {
            data[rowData, index] <- formCharData[[2]]$date[rowData]
            asDatedVector[rowData] <- TRUE
          }
        }
      }
    }
    options(warn = 0)
  }
  return(data)
}

#' Cleansing the dataset on a csv-file to change its form to more arranged one to handle.
#' @encoding UTF-8
#'
#' @param dataName The file-name of a csv file that will be cleansed.
#' @param dateFormat The format assigned to Date group.
#' @param append Allows you to append the new datas generated from dataCleansingForm__.xlsx.
#' @param numOrFac The criteria for classifying whether the column data is numeric or factor. If the number of levels are greater than the ratio (nrow(data)/numOrFac), then it will be assiged to numeric group.
#' @param leastNumOfDate The criteria for classifying whether the column data is Date of numeric. if the data contains the dateFormat you have chosen and the number of data containing such formats is greater than this value, leastNumOfDate, then the data will be assigned to Date group.
#' @param fileEncoding File-encoding
#'
#' @importFrom data.table fread
#' @export
dataCleanser <- function(dataName, dateFormat = list("/", "-"), append = FALSE, numOrFac = 10, leastNumOfDate = 10, fileEncoding = "CP932") {
  files <- list.files()
  if (any(files == paste0("dataCleansingForm_", dataName, "_.xlsx")) == FALSE) {
    data <- as.data.frame(readData(dataName, fileEncoding))
    
    tableTime <- c("ColName", "Change the colName")
    tableNumeric <- c("ColName", "Change the colName", rep("", 6))
    tableFactor <- c("ColName", "Change the colName", rep("", 7))
    
    for (i in colnames(data)) {
      if (!is.null(mkTimeTable(data, dateFormat, i, tableTime, leastNumOfDate))) {
        tableTime <- mkTimeTable(data, dateFormat, i, tableTime, leastNumOfDate)
        next ()
      }
      tableNum_Fac <- mkTableNum_Fac(data, i, numOrFac, tableNumeric, tableFactor)
      tableNumeric <- tableNum_Fac$num
      tableFactor <- tableNum_Fac$fac
    }
    writeTablesOnExcel(tableNumeric, tableFactor, tableTime, dataName)
  }
  else {
    data <- as.data.frame(readData(dataName, fileEncoding))
    dataList <- NULL
    sheetList <- c("numeric", "factor", "Date")
    for (i in seq_len(length(sheetList))) {
      dataList[[i]] <- openxlsx::read.xlsx(paste0("dataCleansingForm_", dataName, "_.xlsx"), sheet = sheetList[i], colNames = F, skipEmptyRows = FALSE, skipEmptyCols = FALSE, na.strings = c("NA", ""))
    }
    for (i in colnames(data)) {
      if (!is.na(any(dataList[[1]][, 1] == i))) {
        data <- cleansNumeric(data, i, dataList[[1]], append)
      }
      if (!is.na(any(dataList[[2]][, 1] == i))) {
        data <- cleansFactor(data, i, dataList[[2]], append)
      }
      if (!is.na(any(dataList[[3]][, 1] == i))) {
        data <- cleansDate(data, i, dataList[[3]], dateFormat)
      }
    }
    return(data)
  }
}